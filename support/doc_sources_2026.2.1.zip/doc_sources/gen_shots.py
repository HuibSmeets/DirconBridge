# Generates the screenshots used in the manual, from the real page CSS in the firmware .ino.
# Usage: python3 gen_shots.py path/to/dircon_bridge_<version>.ino
# Output (in ./shots): setup_1.png, setup_2.png, status_full.png, maint_a.png, maint_b.png, maint_c.png.  Needs: playwright + chromium.
import os, re, sys
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
INO = sys.argv[1] if len(sys.argv) > 1 else sorted(f for f in os.listdir(HERE) if f.endswith(".ino"))[-1]
OUT = os.path.join(HERE, "shots")
os.makedirs(OUT, exist_ok=True)
src = open(INO, encoding="utf-8").read()
HEAD = re.search(r'PAGE_HEAD\[\] = R"HTML\((.*?)\)HTML"', src, re.S).group(1)
MF, VER = "PulseFlow Engineering", re.search(r'FIRMWARE_VERSION\s+"([^"]+)"', src).group(1)
FOOT = "<footer><div class=mf>%s</div><div>Firmware %s</div></footer>" % (MF, VER)


def page(sub, main):
    return HEAD + "<header><h1>BLE - DirCon Bridge</h1><p>%s</p></header><main>%s</main>%s</body></html>" % (sub, main, FOOT)


def row(a, b, cls=""):
    return "<tr><td>%s</td><td class=\"%s\">%s</td></tr>" % (a, cls, b)


setup1 = page("Wi-Fi setup",
    "<div class=note>This device can only connect to <b>2.4&nbsp;GHz</b> Wi-Fi networks.</div>"
    "<form><label>Network</label><select><option>HomeNet-2G (-52 dBm)</option></select>"
    "<label>Password</label><input type=password value=\"password123\">"
    "<label class=chk><input type=checkbox> Show password</label>"
    "<a class='btn sec'>Refresh network list</a><button class='btn pri' type=button>Save and start</button></form>")
setup2 = page("Wi-Fi setup", "<div class=note><b>Saved.</b> The bridge restarts now and connects to <b>HomeNet-2G</b>. "
              "Reconnect your phone to your normal Wi-Fi network; you can close this page.</div>")
def bat(p):
    """Battery level as the status page writes it: coloured text with a small battery icon."""
    cls = "bg" if p > 50 else ("bm" if p >= 25 else "br")
    w = "%.1f" % (p * 11 / 100.0)
    return (" <span class=%s>(<svg width=18 height=10 viewBox='0 0 18 10' style='vertical-align:-1px'><rect x=.5 y=.5 width=14 height=9 rx=1 "
            "fill=none stroke=currentColor /><rect x=15 y=3 width=2 height=4 fill=currentColor /><rect x=2 y=2 width=%s height=6 fill=currentColor /></svg> %d%%)</span>" % (cls, w, p))


IND = "&nbsp;&nbsp;"
status = page("Status", "<table>" + row("Wi-Fi", "HomeNet-2G (-58 dBm)") + row("IP address", "192.168.1.57 (DHCP)")
    + row("Heart rate", "HR: Acme 0249" + bat(72), "ok") + row(IND + "App connections", "1/2", "ok")
    + row("Power / cadence", "CAD: Acme 8C1F" + bat(38), "ok") + row(IND + "App connections", "1/2", "ok")
    + row("Layout", "Separate devices") + row("Uptime", "0d 02:14:09") + "</table>"
    "<h2>Maintenance</h2><p class=hint>Stops the bridging. Then the settings can be changed. Restarting the bridge brings it back to normal operation.</p>"
    "<button class=\"btn sec\">Enter maintenance mode</button>")
maxcl = "".join("<option%s>%d</option>" % (" selected" if n == 2 else "", n) for n in range(2, 6))
maint = page("Maintenance mode",
    "<div class=note>Bridging is stopped. Leave the maintenance mode when you are done.</div>"
    "<div class=card id=c1><h2>DirCon setup</h2><label>Sensor layout</label><select><option>Separate devices (HR and cadence/power)</option></select>"
    "<p class=hint>Combined: no battery level is shown in the app.</p><label>Device name</label><input type=text value=\"Garage\">"
    "<p class=hint>Appended to the DirCon device names and used in the web address. Empty = last 4 digits of the MAC address. Letters, digits, space, - and _ only.</p>"
    "<label>Maximum concurrent connections per sensor</label><select>" + maxcl + "</select>"
    "<p class=hint>Applies to each sensor separately: every sensor accepts this many app connections (with the combined layout, the one combined device accepts this many).</p>"
    "<div class=note style=\"margin-top:10px\"><b>Warning:</b> setting this to more than 2 can cause issues.</div>"
    "<button class=\"btn pri\">Save DirCon setup</button></div>"
    "<div class=card id=c2><h2>Network setup</h2><label>IP address</label><select><option>Automatic (DHCP)</option></select>"
    "<label>Fixed IP address</label><input type=text placeholder=\"192.168.1.50\"><label>Subnet mask</label><input type=text value=\"255.255.255.0\">"
    "<label>Gateway (optional)</label><input type=text placeholder=\"192.168.1.1\">"
    "<label>DNS server (optional)</label><input type=text placeholder=\"192.168.1.1\">"
    "<div class=note style=\"margin-top:10px\"><b>Fixed address:</b> choose an address <b>outside the range your router's DHCP server hands out</b> and not used by another device "
    "(see the DHCP settings of your router), in the same subnet as your network. The four fields are ignored when \"Automatic (DHCP)\" is selected. "
    "If the bridge cannot be reached afterwards, hold the Wi-Fi setup button while connecting power and save the network again: that returns the bridge to DHCP.</div>"
    "<button class=\"btn pri\">Save network setup</button></div>"
    "<div class=card id=c3><h2>Sensors</h2><p><b>Heart rate sensor</b></p><table>" + row("Connected", "HR: Acme HR Strap 0249E23C", "ok")
    + row("Paired", "e1:5a:3c:0f:49:02", "ok") + "</table><button class=\"btn sec\">Unpair</button>"
    "<p><b>Power meter / cadence sensor</b></p><table>" + row("Connected", "PWR: Acme Power 3F2A", "ok") + row("Paired", "no", "no")
    + "</table><button class=\"btn sec\">Pair this sensor</button>"
    "<p class=hint>Paired: the bridge only connects to that sensor. Not paired: it takes the first one it finds. Changes are used after you leave the maintenance mode.</p>"
    "<a class=\"btn sec\">Refresh</a></div>"
    "<div class=card id=c4><h2>System</h2><div class=sub>Firmware update</div><p class=hint>Currently " + VER + ". Choose the firmware file (.bin) you received from " + MF +
    ". It is written next to the running firmware, so a failed or interrupted upload leaves the current firmware untouched. Keep the power connected; the bridge restarts by itself when the upload is done. Your settings are kept.</p>"
    "<label class=\"btn sec\" style=\"font-weight:400\">Choose file</label><button class=\"btn sec\" disabled>Upload and install</button>"
    "<hr><div class=sub>Factory reset</div><button class=\"btn dng\">Factory reset</button>"
    "<p class=hint>Erases the Wi-Fi network, the paired sensors and all settings. The bridge then starts the Wi-Fi setup.</p></div>"
    "<button class=\"btn go\">Leave maintenance mode</button>")

with sync_playwright() as pw:
    br = pw.chromium.launch()

    def shot(html, name, vw, vh, scale, clip_fn=None):
        pg = br.new_page(viewport={"width": vw, "height": vh}, device_scale_factor=scale)
        pg.set_content(html)
        kw = {"path": os.path.join(OUT, name)}
        if clip_fn:
            kw["clip"] = clip_fn(pg)
            kw["full_page"] = True
        pg.screenshot(**kw)
        pg.close()

    bg = "<style>html{background:#f2f4f7}</style>"
    shot(setup1.replace("</head>", bg + "</head>"), "setup_1.png", 390, 580, 3)
    shot(setup2.replace("</head>", bg + "</head>"), "setup_2.png", 390, 580, 3)

    def clip_status(pg):
        b = pg.evaluate("(()=>{const r=document.querySelector('footer').getBoundingClientRect();return r.bottom+scrollY})()")
        return {"x": 0, "y": 0, "width": 390, "height": b + 8}
    shot(status, "status_full.png", 390, 700, 2, clip_status)

    pg = br.new_page(viewport={"width": 390, "height": 300}, device_scale_factor=2)
    pg.set_content(maint)
    top = lambda sel: pg.evaluate("document.querySelector('%s').getBoundingClientRect().top+scrollY" % sel)
    total = pg.evaluate("document.documentElement.scrollHeight")
    cut1, cut2 = top("#c2") - 9, top("#c3") - 9          # between the cards DirCon | Network | Sensors
    for name, y0, y1 in (("maint_a.png", 0, cut1), ("maint_b.png", cut1, cut2), ("maint_c.png", cut2, total)):
        pg.screenshot(path=os.path.join(OUT, name), full_page=True, clip={"x": 0, "y": y0, "width": 390, "height": y1 - y0})
    br.close()
for f in sorted(os.listdir(OUT)):
    print(f)
