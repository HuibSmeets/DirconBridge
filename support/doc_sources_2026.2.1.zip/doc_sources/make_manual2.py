# Builds DirCon_Bridge_User_Manual.pdf (reportlab). Run from any folder:  python3 make_manual2.py
# Needs in the same folder: make_manual.py (helpers), cp images are not used any more;
# shots/setup_1.png, setup_2.png, status_full.png, maint_a.png, maint_b.png (made by gen_shots.py), rouvy_crop.png
import os
HERE = os.path.dirname(os.path.abspath(__file__))
SCR = HERE + os.sep
exec(open(SCR + "make_manual.py").read())

from reportlab.platypus import NextPageTemplate, CondPageBreak
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.graphics import renderPDF
from reportlab.graphics.shapes import Line, Polygon
from reportlab.lib.utils import ImageReader


def img_h(path, width):
    """Height of an image drawn at the given width (keeps the proportions of the real file)."""
    w, h = ImageReader(path).getSize()
    return width * h / float(w)

OUT = SCR + "DirCon_Bridge_User_Manual.pdf"
VERSION = "2026.2.1"          # firmware version the manual describes
MF = "PulseFlow Engineering"
W, H = A4
mono = ParagraphStyle("mono", fontName="Courier", fontSize=8.6, leading=11)
h2 = ParagraphStyle("h2", parent=body, fontName="Helvetica-Bold", fontSize=10.8, textColor=NAVY, spaceBefore=7, spaceAfter=3, keepWithNext=1)
sm = ParagraphStyle("sm", parent=body, fontSize=8.8, leading=12)
bullet = ParagraphStyle("bullet", parent=body, leftIndent=12, firstLineIndent=-9, spaceAfter=2)


def bl(items):
    return [Paragraph("&bull;&nbsp;" + t, bullet) for t in items]


def P(t, st=body):
    return Paragraph(t, st)


# ---------------------------------------------------------------- diagrams
def arrow(d, x1, y, x2, label, col=NAVY):
    d.add(Line(x1, y, x2 - 6, y, strokeColor=col, strokeWidth=1.6))
    d.add(Polygon([x2, y, x2 - 8, y + 4, x2 - 8, y - 4], fillColor=col, strokeColor=col))
    d.add(String((x1 + x2) / 2, y + 6, label, fontName="Helvetica", fontSize=7.6, textAnchor="middle", fillColor=GREY))


def box(d, x, y, w, h, lines, fill=LIGHT, bold=False):
    d.add(Rect(x, y, w, h, rx=6, ry=6, fillColor=fill, strokeColor=NAVY, strokeWidth=1.1))
    n = len(lines)
    for i, t in enumerate(lines):
        d.add(String(x + w / 2, y + h / 2 + (n - 1) * 5 - i * 11 - 3, t, fontName="Helvetica-Bold" if (bold or i == 0) else "Helvetica",
                     fontSize=8.6 if i == 0 else 7.6, textAnchor="middle", fillColor=NAVY))


def system_diagram():
    d = Drawing(493, 150)
    box(d, 0, 92, 128, 40, ["Heart rate sensor", "Bluetooth (BLE)"])
    box(d, 0, 40, 128, 40, ["Cadence sensor or", "power meter (BLE)"])
    box(d, 183, 52, 126, 62, ["BLE - DirCon Bridge", "reads the sensors,", "offers them over Wi-Fi"], fill=colors.HexColor("#d6e2f1"))
    box(d, 365, 74, 128, 40, ["Rouvy / app", "on PC, tablet, phone"])
    box(d, 365, 16, 128, 40, ["Smart trainer", "connected directly"], fill=colors.HexColor("#f3f3f3"))
    arrow(d, 130, 112, 181, "BLE")
    arrow(d, 130, 60, 181, "BLE")
    arrow(d, 311, 94, 363, "Wi-Fi (DirCon)")
    d.add(Line(429, 58, 429, 72, strokeColor=GREY, strokeWidth=1.2, strokeDashArray=[3, 2]))
    d.add(String(247, 22, "The trainer is not touched by the bridge: connect it to the app as usual.", fontName="Helvetica-Oblique", fontSize=7.6, textAnchor="middle", fillColor=GREY))
    return d


# ---------------------------------------------------------------- page decoration
def cover(c, doc):
    c.saveState()
    c.setFillColor(NAVY)
    c.rect(0, H - 150 * mm, W, 150 * mm, stroke=0, fill=1)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 40)
    c.drawString(22 * mm, H - 62 * mm, "BLE - DirCon")
    c.drawString(22 * mm, H - 78 * mm, "Bridge")
    c.setFont("Helvetica", 18)
    c.drawString(22 * mm, H - 96 * mm, "User manual")
    c.setFont("Helvetica", 11)
    c.drawString(22 * mm, H - 112 * mm, "Heart rate, cadence and power sensors to Rouvy and other")
    c.drawString(22 * mm, H - 118 * mm, "Wahoo Direct Connect apps, over Wi-Fi")
    c.setFont("Helvetica-Bold", 12)
    c.drawString(22 * mm, H - 138 * mm, MF)
    c.setFont("Helvetica", 10)
    c.drawRightString(W - 22 * mm, H - 138 * mm, "Firmware %s" % VERSION)
    # illustration: front and back of the box
    for dr, x in ((front_view(), 22 * mm), (back_view(), 108 * mm)):
        dr.scale(0.95, 0.95)
        renderPDF.draw(dr, c, x, 70 * mm)
    c.setFillColor(GREY)
    c.setFont("Helvetica", 9)
    c.drawString(22 * mm, 40 * mm, "Document version for firmware %s  |  November 2026" % VERSION)
    c.drawString(22 * mm, 34 * mm, "A do-it-yourself project. See the small print on the last page.")
    c.restoreState()


def decorate(c, doc):
    c.saveState()
    c.setFillColor(NAVY)
    c.rect(0, H - 36 * mm, W, 36 * mm, stroke=0, fill=1)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 22)
    c.drawString(18 * mm, H - 17 * mm, "BLE - DirCon Bridge")
    c.setFont("Helvetica", 12)
    c.drawString(18 * mm, H - 25 * mm, "User manual")
    c.setFont("Helvetica", 9)
    c.drawRightString(W - 18 * mm, H - 25 * mm, "%s   |   Firmware %s" % (MF, VERSION))
    c.setFillColor(NAVY)
    c.rect(0, 0, W, 11 * mm, stroke=0, fill=1)
    c.setFillColor(colors.white)
    c.setFont("Helvetica", 8.5)
    c.drawString(18 * mm, 4.2 * mm, "%s   |   Firmware %s" % (MF, VERSION))
    c.drawRightString(W - 18 * mm, 4.2 * mm, "Page %d" % doc.page)
    c.restoreState()


class Doc(BaseDocTemplate):
    def afterFlowable(self, fl):
        if isinstance(fl, Paragraph) and fl.style.name == "h1":
            self.notify("TOCEntry", (0, fl.getPlainText(), self.page))


doc = Doc(OUT, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=18 * mm,
          title="BLE - DirCon Bridge - User manual", author=MF, subject="User manual, firmware %s" % VERSION)
cover_frame = Frame(0, 0, W, H, id="c", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
frame = Frame(18 * mm, 15 * mm, W - 36 * mm, H - 36 * mm - 15 * mm, id="f", leftPadding=0, rightPadding=0, topPadding=6, bottomPadding=0)
doc.addPageTemplates([PageTemplate(id="cover", frames=[cover_frame], onPage=cover),
                      PageTemplate(id="main", frames=[frame], onPage=decorate)])

S = []
S.append(Spacer(1, 1))
S.append(NextPageTemplate("main"))
S.append(PageBreak())

# ---------------------------------------------------------------- contents
S.append(Paragraph("Contents", ParagraphStyle("contents", parent=h1, fontSize=16, leading=20, spaceBefore=0, spaceAfter=8)))
toc = TableOfContents()
toc.dotsMinLevel = 0
toc.levelStyles = [ParagraphStyle("toc0", fontName="Helvetica", fontSize=10.5, leading=19, textColor=colors.HexColor("#1b1f24"))]
S.append(toc)
S.append(Spacer(1, 10))
S.append(notebox("<b>About this manual.</b> It describes firmware <b>%s</b>. The screenshots of the status page and the maintenance page use sample data; "
                 "your pages show your own network, sensors and settings. The version of the firmware is shown at the bottom of every page of the bridge." % VERSION))
S.append(PageBreak())

# ---------------------------------------------------------------- 1
S.append(Paragraph("1. About the bridge", h1))
S.append(P("The <b>BLE - DirCon Bridge</b> connects your Bluetooth Low Energy (BLE) heart rate sensor and your cadence sensor or power meter to your "
           "training app over Wi-Fi. It uses the Wahoo Direct Connect (<b>DirCon</b>) protocol, which apps such as Rouvy understand. In the app, "
           "your sensors appear as devices on the network, so you can use sensors that the computer, tablet or phone running the app cannot "
           "reach by Bluetooth, or that are already used by another device."))
S.append(Spacer(1, 4))
S.append(system_diagram())
S.append(Spacer(1, 4))
S.append(P("The bridge only needs power from any 5 V USB charger and a 2.4 GHz Wi-Fi network. It does not need a computer, an account or an internet "
           "connection, and it sends no data anywhere outside your own network."))
S.append(Paragraph("Highlights", h2))
S += bl([
    "<b>Heart rate</b> and <b>cadence or power</b> as separate DirCon devices (with the sensors' own battery levels) or as one combined device.",
    "<b>Power meter or cadence sensor:</b> the second place takes one of the two. A smart trainer's own power still reaches the app directly, as before.",
    "<b>Smart trainers are ignored</b>, so the bridge never connects to your trainer or a neighbour's trainer by mistake.",
    "<b>Optional pairing</b> locks the bridge to your own sensors; without pairing it simply uses the first suitable sensors it finds.",
    "<b>Four LEDs</b> show Wi-Fi, heart rate, cadence / power and app connection at a glance.",
    "<b>Status page</b> in any browser that shows what the bridge is doing, without disturbing it.",
    "<b>Maintenance mode</b> for settings (layout, name, fixed IP address), pairing and un-pairing, firmware updates and factory reset.",
    "Several bridges on one network are told apart by a 4-character code or a name you choose.",
])
S.append(Paragraph("What you need", h2))
S.append(grid([
    [hdr("Item"), hdr("Notes")],
    [P("<b>5 V USB power</b>", cell), P("Any USB charger or a USB port, with a USB-C cable.", cell)],
    [P("<b>2.4 GHz Wi-Fi</b>", cell), P("With the password. 5 GHz-only networks cannot be used (see the troubleshooting tip about separate network names).", cell)],
    [P("<b>BLE sensors</b>", cell), P("A heart rate sensor, and a cadence sensor (crank) or a power meter that offers power with or without cadence. Not connected to another device while you use the bridge.", cell)],
    [P("<b>An app with DirCon</b>", cell), P("Rouvy, or another app that supports Wahoo Direct Connect, on a device in the <b>same network</b> as the bridge.", cell)],
    [P("<b>A phone or computer</b>", cell), P("For the Wi-Fi setup and for the status and maintenance pages (any browser).", cell)],
], [42 * mm, 132 * mm]))

# ---------------------------------------------------------------- 2
S.append(Paragraph("2. Quick start", h1))
S += steps([
    "Connect the bridge to power with the USB-C cable. The four LEDs flash once.",
    "The first time, the <b>Wi-Fi LED blinks slowly</b>: the bridge waits for the Wi-Fi setup. On your phone, join the network <b>DirCon-Setup-xxxx</b>, pick your own network and enter its password (section 4).",
    "When the bridge is on your network, the <b>Wi-Fi LED stays on</b>.",
    "Wake your sensors (put on the heart rate strap, turn the crank). Within a few seconds the <b>HR</b> and <b>Cadence / Power</b> LEDs turn on.",
    "Start your app, search for sensors and pick <b>DirCon HR xxxx</b> for heart rate and <b>DirCon CAD xxxx</b> or <b>DirCon PWR xxxx</b> for cadence or power (section 9). The <b>DirCon LED</b> turns on when the app is connected.",
])
S.append(Spacer(1, 3))
S.append(notebox("Optional: <b>pair</b> your sensors so that the bridge only uses those (section 5), and look at the <b>status page</b> (section 6) to see what the bridge is doing."))

# ---------------------------------------------------------------- 3
S.append(CondPageBreak(95 * mm))
S.append(Paragraph("3. The box: LEDs and buttons", h1))
dg = Table([[front_view(), back_view()]], colWidths=[87 * mm, 87 * mm])
dg.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
for dr in (dg._cellvalues[0][0], dg._cellvalues[0][1]):
    dr.scale(0.9, 0.9)
    dr.width *= 0.9
    dr.height *= 0.9
S.append(dg)
S.append(Spacer(1, 5))
S.append(Paragraph("The four LEDs", h2))
S.append(grid([
    [hdr("LED"), hdr("Off"), hdr("On"), hdr("Blinking")],
    [P("<b>Wi-Fi</b>", cell), P("Not connected to your network (the bridge keeps trying)", cell),
     P("Connected to your network", cell), P("Slowly: Wi-Fi setup is active, a network must be entered (section 4)", cell)],
    [P("<b>HR</b>", cell), P("No heart rate sensor connected (searching)", cell),
     P("Heart rate sensor connected", cell), P("Pairing with the button only: searching for the sensor", cell)],
    [P("<b>Cadence / Power</b>", cell), P("No cadence sensor or power meter connected (searching)", cell),
     P("Cadence sensor or power meter connected", cell), P("Pairing with the button only: searching for the sensor", cell)],
    [P("<b>DirCon</b>", cell), P("No app connected", cell),
     P("Rouvy (or another app) is connected to the bridge", cell), P("-", cell)],
], [27 * mm, 52 * mm, 49 * mm, 46 * mm]))
S.append(Spacer(1, 4))
S.append(P("In the <b>maintenance mode</b> (section 7) only the Wi-Fi LED is on; the other LEDs stay off, even when sensors are connected, because nothing is being bridged.", sm))
S.append(Spacer(1, 3))
S.append(P("<b>Low battery.</b> While the battery of a connected sensor is below 25 %, the LED of that sensor (HR or Cadence / Power) goes off briefly every 3 seconds. "
           "The battery level is also shown on the status page (section 6).", sm))
S.append(Paragraph("The two buttons (on the back)", h2))
S.append(P("The buttons work when the bridge <b>starts</b>: hold the button while you connect the power, and keep it held until the four LEDs have flashed once.", body))
S.append(Spacer(1, 3))
S.append(grid([
    [hdr("Held while connecting power"), hdr("What happens")],
    [P("Nothing", cell), P("Normal start: the bridge connects to Wi-Fi and looks for the sensors.", cell)],
    [P("<b>Pairing</b> button (left)", cell), P("Pairing mode: the bridge searches for your sensors and stores them (section 5).", cell)],
    [P("<b>Wi-Fi setup</b> button (right)", cell), P("Wi-Fi setup: the bridge opens its own setup network so you can enter another Wi-Fi network (section 4).", cell)],
    [P("<b>Both</b> buttons", cell), P("Factory reset after a 10-second hold and an LED countdown; release a button to cancel (section 8).", cell)],
], [58 * mm, 116 * mm]))

# ---------------------------------------------------------------- 4
S.append(CondPageBreak(120 * mm))
S.append(Paragraph("4. Wi-Fi setup", h1))
S.append(P("The Wi-Fi setup is needed the first time (the bridge starts it by itself when no network is stored), and whenever you want to use another network. "
           "To start it again later: <b>hold the Wi-Fi setup button (right of the USB-C connector) while connecting power</b>. "
           "During the setup the bridge does nothing else; it opens an access point and a simple page for your phone.", body))
S.append(Spacer(1, 3))
wifi_steps = steps([
    "The <b>Wi-Fi LED blinks slowly</b>. The bridge now does nothing else than wait for the setup.",
    "On your phone, open the Wi-Fi settings and join the network <b>DirCon-Setup-xxxx</b> (xxxx = 4 characters, no password).",
    "The setup page opens by itself like a &quot;sign in&quot; page (captive portal). If it does not, open your browser and go to <b>192.168.4.1</b>.",
    "Pick your Wi-Fi network from the list. A hidden network: choose <i>Other network</i> and type its name. <i>Refresh network list</i> scans again.",
    "Enter the password (tick <i>Show password</i> to check it) and tap <b>Save and start</b>.",
    "The bridge restarts and connects. The <b>Wi-Fi LED turns on</b> when it is connected. Connect your phone back to your normal network.",
])
_w = 37.5 * mm
_h = _w * 580 / 390
_shots = Table([[Image(SCR + "shots/setup_1.png", width=_w, height=_h), Image(SCR + "shots/setup_2.png", width=_w, height=_h)],
                [Paragraph("The setup page", cap), Paragraph("After saving", cap)]], colWidths=[_w + 1 * mm, _w + 1 * mm])
_shots.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 1), ("RIGHTPADDING", (0, 0), (-1, -1), 1),
                            ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0)]))
_both = Table([[wifi_steps, _shots]], colWidths=[97 * mm, 77 * mm])
_both.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                           ("RIGHTPADDING", (0, 0), (0, 0), 6), ("RIGHTPADDING", (1, 0), (1, 0), 0),
                           ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0)]))
S.append(_both)
S.append(Spacer(1, 3))
S.append(notebox("<b>2.4 GHz only.</b> The bridge cannot use 5 GHz-only networks. Most routers offer both bands; see the tip in section 10. "
                 "The network is remembered when the power is off. If it is out of reach or the password was wrong, the Wi-Fi LED stays off and the bridge "
                 "keeps trying; repeat the setup to correct it. A new network saved here also switches the bridge back to automatic (DHCP) addressing."))

# ---------------------------------------------------------------- 5
S.append(Paragraph("5. Sensors and pairing", h1))
S.append(Paragraph("How the bridge chooses sensors", h2))
S.append(P("The bridge has <b>two places</b> for sensors. The first is for a <b>heart rate</b> sensor. The second takes <b>either a cadence sensor or a power meter</b>, "
           "whichever is found or paired; it is never both. A power meter offers power and, when it supports it, cadence. If a device offers "
           "both power and cadence services, it is used as a power meter.", body))
S.append(Spacer(1, 3))
S += bl([
    "<b>Not paired:</b> the bridge connects to the first heart rate sensor and the first cadence sensor or power meter that it finds. It starts searching again if a sensor drops out.",
    "<b>Paired:</b> that place is locked to the one sensor you paired. All other sensors are ignored. A type you did not pair still uses the first sensor of that type it finds.",
    "<b>Smart trainers</b> (devices that offer the Fitness Machine service) are never used or paired. Connect the trainer to your app directly.",
    "A sensor can only be connected to one device at a time. Disconnect it from your phone, watch or bike computer first.",
])
S.append(Paragraph("What the app sees", h2))
S.append(P("The bridge announces a DirCon device on your network <b>only while at least one of its sensors is connected</b>, and offers only the services of connected sensors. "
           "When a sensor drops out, its device disappears from the app; it returns when the sensor is back. Each device reports the manufacturer "
           "<i>%s</i>; <i>Model #</i> shows the make and name of the real sensor behind it, and the battery level is the sensor's own (separate layout only)." % MF, body))
S.append(Spacer(1, 3))
S.append(KeepTogether(grid([
    [hdr("Layout"), hdr("Devices in the app"), hdr("Battery level")],
    [P("<b>Separate devices</b> (default)", cell), P("<b>DirCon HR xxxx</b> and <b>DirCon CAD xxxx</b> or <b>DirCon PWR xxxx</b>", cell), P("Shown for each device", cell)],
    [P("<b>One combined device</b>", cell), P("<b>DirCon Sensors xxxx</b> with all connected sensors (e.g. for Zwift)", cell), P("Not shown", cell)],
], [50 * mm, 90 * mm, 34 * mm])))
S.append(Spacer(1, 3))
S.append(P("<b>xxxx</b> is a 4-character code from the bridge's own address, or the device name you set in the maintenance mode. With a combined device, apps connected to it are disconnected once "
           "when its set of sensors changes, so they reconnect and see the new services.", sm))
S.append(Spacer(1, 4))
S.append(Paragraph("Pairing with the button (optional)", h2))
S.append(P("Pair your own sensors to make sure the bridge never picks up someone else's, for instance in a club or gym. You can pair both sensors at once with the button, or one at a time in the maintenance mode (section 7).", body))
S.append(Spacer(1, 3))
S += steps([
    "Wake your sensors: put on the heart rate sensor and turn the crank. Keep them <b>close to the bridge</b> (a metre or two) and "
    "make sure they are <b>not connected to another device</b>.",
    "<b>Hold the pairing button (left of the USB-C connector) while connecting power</b>, until the four LEDs have flashed. Release it.",
    "The <b>HR</b> and <b>Cadence / Power</b> LEDs now blink: the bridge is searching. A LED <b>stays on</b> when its sensor has been found.",
    "When both sensors are found, pairing <b>ends by itself</b> after about two seconds. To pair only one sensor, <b>press the pairing button once more</b> when its LED is on.",
    "The LEDs go off and the bridge starts normally, connecting to the paired sensor(s).",
])
S.append(Spacer(1, 3))
S.append(notebox("Starting pairing first erases all earlier pairings. Ending it without finding anything (press the button again straight away) therefore "
                 "<b>un-pairs everything</b> and brings the bridge back to connecting to any sensor. Pairings are kept when the power is off and when the Wi-Fi network is changed. "
                 "Only the sensors found with a signal of at least -80 dBm are accepted: keep them close."))

# ---------------------------------------------------------------- 6
S.append(CondPageBreak(135 * mm))
S.append(Paragraph("6. The status page", h1))
S.append(P("As soon as the bridge is on your network, you can look at what it is doing. Open <b>http://dircon-bridge-xxxx.local</b> in a browser on a phone or computer on the "
           "same network (xxxx = the device name you chose in the maintenance mode, or the 4-character code if you chose none). If that name does not work, use the bridge's "
           "IP address, which you find in your router's list of devices. The page runs separately from the bridging: it only <i>shows</i> and never disturbs the data while you ride.", body))
S.append(Spacer(1, 5))
st_w = 55 * mm
img_status = Image(SCR + "shots/status_full.png", width=st_w, height=img_h(SCR + "shots/status_full.png", st_w))
GREEN, ORANGE, RED = "#1e8449", "#d35400", "#c0392b"
legend = [P("<b>What the page shows</b>", body), Spacer(1, 3), grid([
    [hdr("Line"), hdr("Meaning")],
    [P("<b>Wi-Fi</b>", cell), P("Name of your network and the signal strength (closer to 0 dBm is stronger).", cell)],
    [P("<b>IP address</b>", cell), P("Address of the bridge, and whether it comes from DHCP (automatic) or is fixed.", cell)],
    [P("<b>Heart rate</b>", cell), P("The connected heart rate sensor, or <i>searching</i>. After the name: the battery level of the sensor.", cell)],
    [P("<b>Power / cadence</b>", cell), P("The connected cadence sensor (CAD) or power meter (PWR), or <i>searching</i>. After the name: its battery level.", cell)],
    [P("<b>App connections</b>", cell), P("On the line below each sensor: how many apps are connected to the DirCon device of that sensor, out of the maximum set in the maintenance mode "
                                         "(for example 1/2). With the combined layout both lines show the same device.", cell)],
    [P("<b>Layout</b>", cell), P("Separate devices or one combined device.", cell)],
    [P("<b>Uptime</b>", cell), P("Time since the bridge was started (days hh:mm:ss).", cell)],
], [31 * mm, 80 * mm]), Spacer(1, 5),
    P("<b>Battery level.</b> The percentage is shown in <font color='%s'><b>green</b></font> above 50 %%, <font color='%s'><b>orange</b></font> from 25 to 50 %% and "
      "<font color='%s'><b>red</b></font> below 25 %%. It is read every few minutes and appears when the sensor has reported it." % (GREEN, ORANGE, RED), sm), Spacer(1, 3),
    P("<b>Connections.</b> An app that uses both the heart rate and the cadence / power device counts once on each line.", sm), Spacer(1, 3),
    P("The page refreshes itself every few seconds. The button <b>Enter maintenance mode</b> at the bottom is described in section 7.", sm)]
t = Table([[[img_status, Paragraph("Status page (sample data)", cap)], legend]], colWidths=[st_w + 6 * mm, 174 * mm - st_w - 6 * mm])
t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (0, 0), 6),
                       ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0)]))
S.append(t)
S.append(Spacer(1, 5))
S.append(notebox("<b>No password.</b> Everybody on your Wi-Fi network can open the status page and enter the maintenance mode. Use the bridge on a network you trust."))

# ---------------------------------------------------------------- 7
S.append(PageBreak())
S.append(Paragraph("7. Maintenance mode", h1))
S.append(P("The maintenance mode is for changing settings, pairing sensors, updating the firmware and resetting the bridge. While it is active <b>the bridging is stopped</b>: "
           "apps lose the bridge's devices, and only the Wi-Fi LED is on. The bridge is still on your network, so you use it from a browser.", body))
S.append(Spacer(1, 3))
S += steps([
    "Open the status page (section 6) and tap <b>Enter maintenance mode</b>. Confirm the question.",
    "The bridge restarts. Wait about 10 to 20 seconds; the page reloads by itself and shows the maintenance page below.",
    "Change what you need. Each card saves by itself with its own button.",
    "Tap <b>Leave maintenance mode</b> (green). The bridge restarts and starts bridging again. Settings, pairing changes and a fixed IP address are used from then on.",
])
S.append(Spacer(1, 3))
S.append(P("Maintenance mode also ends by itself after <b>15 minutes without use</b>, and when you disconnect and reconnect the power. Everything you saved with the card buttons is kept; "
           "only text typed but not saved is lost.", body))
S.append(Spacer(1, 6))
S.append(P("<b>The maintenance page</b> (sample data)", ParagraphStyle("mp", parent=body, fontSize=10.5, textColor=NAVY)))
S.append(Spacer(1, 3))
mw = 50 * mm
mi = [Image(SCR + "shots/maint_%s.png" % k, width=mw, height=img_h(SCR + "shots/maint_%s.png" % k, mw)) for k in "abc"]
leg2 = [P("<b>The four cards</b>", sm), Spacer(1, 2),
        P("<b>DirCon setup.</b> Sensor layout (separate devices, or one combined device without battery level), device name (up to 20 characters: letters, digits, space, - and _; "
          "added to the DirCon device names and to the web address, <font face='Courier'>dircon-bridge-garage.local</font>; empty = the 4-character code) and the maximum number "
          "of app connections per sensor (2 to 5, default 2; more than 2 can cause issues). <b>Save DirCon setup</b> saves only these.", cell), Spacer(1, 3),
        P("<b>Network setup.</b> Automatic (DHCP) or a fixed IP address with subnet mask, optional gateway and optional DNS server. Choose an address <b>outside the DHCP range</b> "
          "of your router, not used by another device, in your own subnet. A wrong entry is refused with an explanation. <b>Save network setup</b> saves only these.", cell), Spacer(1, 3),
        P("<b>Sensors.</b> The connected sensors and their pairing; pair or un-pair (below).", cell), Spacer(1, 3),
        P("<b>System.</b> Firmware update and factory reset (below).", cell), Spacer(1, 3),
        P("<b>Leave maintenance mode.</b> Restarts the bridge into normal operation.", cell)]
gap = 2 * mm
mt = Table([[mi[0], mi[1], mi[2]], [leg2, "", ""]], colWidths=[mw + gap, mw + gap, mw], hAlign="LEFT")
mt.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (1, -1), gap),
                        ("RIGHTPADDING", (2, 0), (2, -1), 0), ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                        ("TOPPADDING", (0, 1), (1, 1), 6),
                        ("SPAN", (2, 0), (2, 1)), ("SPAN", (0, 1), (1, 1))]))
S.append(mt)
S.append(PageBreak())

S.append(P("<b>Pairing and un-pairing in the maintenance mode</b>", ParagraphStyle("mp2", parent=body, fontSize=11, textColor=NAVY, spaceAfter=3)))
S.append(P("The <b>Sensors</b> card has one block for the heart rate sensor and one for the cadence sensor / power meter. In maintenance mode the bridge keeps looking for sensors, "
           "so the card shows what is connected right now. Each block shows <b>Connected</b> (the sensor the bridge is connected to, or <i>searching</i>) and <b>Paired</b> "
           "(the stored sensor, or <i>no</i>). Only <b>one</b> button is shown per block, depending on the situation:", body))
S.append(Spacer(1, 3))
S.append(grid([
    [hdr("Connected"), hdr("Paired"), hdr("Button shown")],
    [P("a sensor", cell), P("no", cell), P("<b>Pair this sensor</b>: stores the connected sensor", cell)],
    [P("a sensor or <i>searching</i>", cell), P("an address", cell), P("<b>Unpair</b>: removes the pairing", cell)],
    [P("<i>searching</i>", cell), P("no", cell), P("none: there is nothing to pair yet (wake the sensor, tap <b>Refresh</b>)", cell)],
], [44 * mm, 36 * mm, 94 * mm]))
S.append(Spacer(1, 4))
S.append(P("<b>To pair a sensor</b>", ParagraphStyle("h3", parent=body, fontName="Helvetica-Bold", keepWithNext=1)))
S += steps([
    "Wake the sensor, keep it close to the bridge and disconnect it from other devices.",
    "Enter the maintenance mode and look at the <b>Sensors</b> card. Wait until your sensor appears next to <b>Connected</b> (tap <b>Refresh</b>; this can take some seconds). "
    "Check that the name is your sensor: the bridge connects to the first one it finds, which can be a neighbour's.",
    "Tap <b>Pair this sensor</b>. The page confirms <i>Sensor paired</i> and <b>Paired</b> now shows the sensor's address.",
    "Tap <b>Leave maintenance mode</b>. From now on the bridge connects only to this sensor.",
])
S.append(Spacer(1, 3))
S.append(P("<b>To un-pair a sensor</b>", ParagraphStyle("h3b", parent=body, fontName="Helvetica-Bold", keepWithNext=1)))
S += steps([
    "Enter the maintenance mode and find the sensor's block. The sensor does not need to be on or nearby.",
    "Tap <b>Unpair</b> (confirm). The page confirms <i>Sensor unpaired</i> and <b>Paired</b> shows <i>no</i>.",
    "Tap <b>Leave maintenance mode</b>. The bridge connects to any sensor of that type again.",
])
S.append(Spacer(1, 3))
S.append(notebox("<b>Changing to another sensor</b> (for example a different heart rate strap, or a power meter instead of a cadence sensor): "
                 "<b>un-pair first and leave the maintenance mode</b>, then enter it again, wait until the new sensor is shown as <b>Connected</b> and tap <b>Pair this sensor</b>. "
                 "While a sensor is paired the bridge ignores all others of that block, so a new one cannot show up before the old pairing is removed and the bridge has restarted. "
                 "Pairing with the button at power-up (section 5) is the quicker way to start completely over."))
S.append(Paragraph("Updating the firmware", h2))
S.append(P("You need the firmware file (<b>.bin</b>) you received from %s, on the phone or computer you use for the maintenance page." % MF, body))
S.append(Spacer(1, 3))
S += steps([
    "Enter the maintenance mode and find the <b>System</b> card.",
    "Tap <b>Choose file</b> and select the .bin file. The <b>Upload and install</b> button turns from grey to blue.",
    "Tap <b>Upload and install</b>. <b>Keep the power connected</b> until the upload is finished; it takes under a minute.",
    "The bridge restarts by itself with the new firmware and the page reloads. The version is shown at the bottom of every page. Your Wi-Fi network, pairings and settings are kept.",
])
S.append(Spacer(1, 3))
S.append(notebox("The new firmware is written next to the running one. If the upload fails or is interrupted (wrong file, connection lost), the page shows an error "
                 "and the current firmware keeps working: tap <b>Leave maintenance mode</b> or simply try again."))
S.append(Paragraph("Factory reset in the maintenance mode", h2))
S.append(P("<b>Factory reset</b> in the System card asks for confirmation, then erases the Wi-Fi network, the paired sensors and all settings and restarts the bridge into the Wi-Fi setup. "
           "The page then shows the name of the setup network (<b>DirCon-Setup-xxxx</b>); if the sign-in page does not appear on your phone, open <b>http://192.168.4.1</b> in the browser.", body))

# ---------------------------------------------------------------- 8
S.append(CondPageBreak(90 * mm))
S.append(Paragraph("8. Factory reset with the buttons, and recovery", h1))
S.append(P("If the status page cannot be reached (for example after a wrong fixed IP address), the bridge can be reset with its buttons:", body))
S.append(Spacer(1, 3))
S += steps([
    "<b>Hold both buttons</b> (pairing and Wi-Fi setup) while connecting power. The four LEDs flash once.",
    "<b>Keep holding for 10 seconds.</b> All LEDs are off during this time.",
    "All four LEDs turn on. Every <b>3 seconds</b> one LED goes off, from right to left: DirCon, Cadence / Power, HR, Wi-Fi.",
    "When the last LED is off, all LEDs flash and the bridge erases the Wi-Fi network, the pairings and all settings and restarts. "
    "<b>Release the buttons now</b>; the Wi-Fi LED blinks and the bridge waits for the Wi-Fi setup (section 4).",
])
S.append(Spacer(1, 3))
S.append(notebox("<b>To cancel, release one or both buttons at any moment</b> before the last LED has gone off. Nothing is erased and the bridge starts normally. "
                 "If you only need to leave a wrong fixed IP address, the Wi-Fi setup is enough: saving a network there also switches the bridge back to DHCP."))
S.append(Spacer(1, 4))
S.append(P("<b>If the bridge does not start at all</b> (no LED flash when power is connected, no status page, or a firmware update went wrong), it can be recovered over the USB-C cable. "
           "This is described in the separate <b>Device Recovery Guide</b>, which also tells you where to get the tools and the recovery file.", body))

# ---------------------------------------------------------------- 9
S.append(CondPageBreak(100 * mm))
S.append(Paragraph("9. Using the bridge with Rouvy and other apps", h1))
S.append(P("Connect your sensors first (the HR and Cadence / Power LEDs on), and make sure the bridge and the device running the app are on the "
           "<b>same Wi-Fi network</b>. Each connected sensor then shows up in the app as its own device. It disappears again when the sensor "
           "disconnects and returns when the sensor is back.", body))
S.append(Spacer(1, 5))
S.append(grid([
    [hdr("Name in the app"), hdr("What it is")],
    [P("<b>DirCon HR xxxx</b>", cell), P("Your heart rate sensor", cell)],
    [P("<b>DirCon CAD xxxx</b>", cell), P("Your cadence sensor", cell)],
    [P("<b>DirCon PWR xxxx</b>", cell), P("Your power meter (power and cadence)", cell)],
    [P("<b>DirCon Sensors xxxx</b>", cell), P("Combined layout: all connected sensors in one device", cell)],
], [60 * mm, 114 * mm]))
S.append(Spacer(1, 4))
S.append(P("<b>xxxx</b> is the same 4-character code as in the setup network name (for example 03A4), or the device name you chose in the maintenance mode. It tells several bridges apart. "
           "Select these devices in the app for heart rate and for cadence or power. In the details of a device, <i>Manufacturer</i> shows "
           "%s, <i>Model #</i> shows the make and name of the real sensor behind it, and the battery level is the sensor's own." % MF, body))
S.append(Spacer(1, 6))
img = Image(SCR + "rouvy_crop.png", width=62 * mm, height=62 * mm * 864 / 868)
S.append(KeepTogether([img, Spacer(1, 2), Paragraph("Example: the heart rate device of a bridge with code 03A4", cap)]))
S.append(Spacer(1, 4))
S.append(P("<b>With a smart trainer:</b> connect the trainer to the app directly for power and resistance. With a cadence sensor, use the trainer's power "
           "plus the cadence from <i>DirCon CAD</i>. With a power meter you can use <i>DirCon PWR</i> for power and cadence. "
           "For apps that want one device with everything, choose the <i>combined</i> layout in the maintenance mode.", body))

# ---------------------------------------------------------------- 10
S.append(PageBreak())
S.append(Paragraph("10. Troubleshooting", h1))
S.append(grid([
    [hdr("What you see"), hdr("What to do")],
    [P("Wi-Fi LED blinks", cell), P("The bridge is waiting for the Wi-Fi setup. Complete it (section 4).", cell)],
    [P("Wi-Fi LED stays off", cell), P("Wrong password, network out of reach, or a 5 GHz-only network. Move the bridge closer or repeat the Wi-Fi setup.", cell)],
    [P("HR or Cadence / Power LED stays off", cell), P("Wake the sensor, check its battery, bring it closer and disconnect it from other devices. If you paired a different sensor before, un-pair it or repeat the pairing.", cell)],
    [P("LED on, device missing in the app", cell), P("Check that the app and the bridge are on the same network. Some guest networks block devices from seeing each other. Search for devices again in the app.", cell)],
    [P("Status page does not open", cell), P("The phone or computer must be on the same Wi-Fi network as the bridge. Try the IP address from your router's device list instead of the .local name.", cell)],
    [P("No <i>Pair this sensor</i> button", cell), P("The sensor is not connected yet or is already paired (then <b>Unpair</b> is shown). Wake the sensor, tap <b>Refresh</b>, see section 7.", cell)],
    [P("Bridge stays in maintenance mode", cell), P("Tap <b>Leave maintenance mode</b> on the page, or disconnect and reconnect the power.", cell)],
    [P("Bridge not reachable after setting a fixed IP address", cell), P("The address does not fit your network or is already in use. Hold the Wi-Fi setup button while connecting power and save the network again: the bridge returns to DHCP. Or use the factory reset with both buttons (section 8).", cell)],
    [P("Firmware update fails", cell), P("Check that you chose the .bin file you received for this bridge and try again. The current firmware stays in place. Keep the power connected during the upload.", cell)],
    [P("Forgot the Wi-Fi network or everything is wrong", cell), P("Use <b>Factory reset</b> in the maintenance mode, hold both buttons while connecting power (section 8), or hold the Wi-Fi setup button while connecting power (section 4).", cell)],
    [P("Bridge does not start at all", cell), P("Use the Device Recovery Guide (USB recovery).", cell)],
    [P("Router uses one network name for 2.4 and 5 GHz", cell),
     P("<b>Best practice:</b> give the 2.4 GHz and the 5 GHz network each their own name (SSID), for example MyNetwork and MyNetwork-5G. "
       "With one shared name the router may steer devices to 5 GHz, which the bridge cannot use, and you cannot tell which band you pick in the list. "
       "Choose the 2.4 GHz network in the Wi-Fi setup.", cell)],
    [P("A sensor LED goes off briefly every 3 seconds", cell), P("The battery of that sensor is below 25 %. Replace or charge it. The level is also shown on the status page (section 6).", cell)],
    [P("Anything else", cell), P("Unplug the USB-C cable and connect it again.", cell)],
], [52 * mm, 122 * mm]))

# ---------------------------------------------------------------- 11
S.append(Paragraph("11. Specifications", h1))
S.append(grid([
    [hdr("Item"), hdr("Value")],
    [P("Power", cell), P("USB-C, 5 V", cell)],
    [P("Processor / radio", cell), P("ESP32-S3 (Seeed Studio XIAO ESP32S3); Wi-Fi 2.4 GHz only; Bluetooth Low Energy", cell)],
    [P("Supported sensors", cell), P("Heart rate (Heart Rate service), cadence (Cycling Speed and Cadence, crank), power meter (Cycling Power)", cell)],
    [P("Sensors at a time", cell), P("One heart rate sensor, and one cadence sensor or power meter", cell)],
    [P("Protocol to the app", cell), P("Wahoo Direct Connect over TCP (ports 36866 and 36867 for the separate layout; 36866 for the combined layout), announced with mDNS", cell)],
    [P("Web pages", cell), P("Port 80, no password: status page (always) and maintenance page (maintenance mode)", cell)],
    [P("Addressing", cell), P("DHCP (default) or a fixed IP address, with an optional DNS server", cell)],
    [P("Stored in flash", cell), P("Wi-Fi network, paired sensors, layout, device name, connection limit, IP settings; kept when the power is off and after firmware updates", cell)],
    [P("App connections", cell), P("Per DirCon device: 2 by default, 2 to 5 can be set in the maintenance mode", cell)],
], [42 * mm, 132 * mm]))

# ---------------------------------------------------------------- 12 small print
S.append(PageBreak())
S.append(Paragraph("12. Small print", h1))
sp = ParagraphStyle("sp", parent=body, fontSize=9.2, leading=12.6, spaceAfter=5)
S.append(Paragraph("DIY project, no warranty", h2))
S.append(P("The BLE - DirCon Bridge is a <b>do-it-yourself (DIY) project</b>. The hardware, firmware and documentation are provided <b>\"as is\"</b>, without warranty of any kind, "
           "<b>either express or implied</b>, including but not limited to the implied warranties of merchantability, fitness for a particular purpose and non-infringement. "
           "You build, use and update the bridge at your own risk.", sp))
S.append(P("To the fullest extent permitted by law, the authors and %s are not liable for any damage or loss arising from the building or use of the bridge, "
           "including damage to equipment (trainers, sensors, computers, routers), loss of data, loss of training results or accounts, or injury." % MF, sp))
S.append(Paragraph("Not a medical device, not certified", h2))
S.append(P("The bridge passes on sensor data for training purposes only. It is <b>not a medical device</b> and must not be used for medical decisions. "
           "The bridge has <b>not been tested or certified</b> for CE, UKCA, FCC or similar requirements. If you build or use it, you are responsible for complying with the rules that apply to you. "
           "Power it only from a certified 5 V USB power supply and do not use it in a way that could cause harm if it stops working.", sp))
S.append(Paragraph("Software license", h2))
S.append(P("The firmware is <b>free software</b>, released under the <b>GNU General Public License (GPL), version 3</b>. You may redistribute and modify it under the terms of that license. "
           "It is distributed in the hope that it will be useful, but <b>WITHOUT ANY WARRANTY</b>; without even the implied warranty of merchantability or fitness for a particular purpose. "
           "See <font face='Courier'>https://www.gnu.org/licenses/gpl-3.0.html</font> and the LICENSE file in the source code repository. "
           "If you distribute the firmware or a modified version, you must make the corresponding source code available under the same license.", sp))
S.append(P("The firmware uses third-party software under its own licenses, among them the Arduino-ESP32 core, Espressif's ESP-IDF and the NimBLE-Arduino library. "
           "Their license terms apply to those parts.", sp))
S.append(Paragraph("Trademarks and compatibility", h2))
S.append(P("Wahoo, Rouvy, Zwift, Bluetooth, Seeed Studio, XIAO, Espressif and other product and company names are trademarks or registered trademarks of their respective owners. "
           "This project is <b>not affiliated with, endorsed by or sponsored by</b> any of them. Compatibility with apps and sensors is based on publicly available information "
           "and cannot be guaranteed; apps and sensors may change their behaviour at any time.", sp))
S.append(Paragraph("Privacy and security", h2))
S.append(P("The bridge works inside your own network and sends no data to the internet. The status page and the maintenance page have <b>no password</b>: anybody on your Wi-Fi network can open them. "
           "Use the bridge only on a network you trust, and keep your router's Wi-Fi password private.", sp))
S.append(Spacer(1, 6))
S.append(P("Document for firmware %s. Contents may change without notice. &copy; 2026 %s." % (VERSION, MF), small))

doc.multiBuild(S)
print("ok ->", OUT)
