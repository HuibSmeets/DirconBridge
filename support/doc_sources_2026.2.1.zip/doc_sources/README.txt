Documentation sources - BLE - DirCon Bridge (PulseFlow Engineering)
Needs: python3, reportlab, playwright+chromium (gen_shots.py only).
  python3 gen_shots.py <firmware>.ino   -> shots/*.png (real page CSS from the .ino, sample data; maint_a/b/c = three parts of the maintenance page)
  python3 make_manual2.py               -> DirCon_Bridge_User_Manual.pdf (execs make_manual.py)
  python3 make_recovery.py              -> DirCon_Bridge_Recovery_Guide.pdf
make_manual.py = shared styles/helpers only. rouvy_crop.png = Rouvy screenshot used in section 9.
cp1.png / cp2.png = old captive-portal phone screenshots, no longer used by the manual.
Describes firmware 2026.2.1 (VERSION in make_manual2.py; shots made with dircon_bridge_2026.2.1.ino).
Image heights in the manual are taken from the real PNG files (img_h), so new shots need no manual size changes.
