# Builds DirCon_Bridge_Recovery_Guide.pdf (reportlab). Run:  python3 make_recovery.py
# Needs make_manual.py (shared styles) in the same folder.
import os
HERE = os.path.dirname(os.path.abspath(__file__))
SCR = HERE + os.sep
exec(open(SCR + "make_manual.py").read())
from reportlab.platypus import CondPageBreak

OUT = SCR + "DirCon_Bridge_Recovery_Guide.pdf"
MF = "PulseFlow Engineering"
W, H = A4
sm = ParagraphStyle("sm", parent=body, fontSize=8.8, leading=12)
code = ParagraphStyle("code", fontName="Courier", fontSize=8.8, leading=11.5, textColor=colors.HexColor("#1b1f24"),
                      backColor=colors.HexColor("#eef1f5"), borderPadding=(3, 4, 3, 4), leftIndent=6, spaceBefore=2, spaceAfter=5)
h2 = ParagraphStyle("h2", parent=body, fontName="Helvetica-Bold", fontSize=10.6, textColor=NAVY, spaceBefore=6, spaceAfter=3, keepWithNext=1)
P = lambda t, st=body: Paragraph(t, st)
C = lambda t: Paragraph(t, code)


def decorate(c, doc):
    c.saveState()
    c.setFillColor(NAVY)
    c.rect(0, H - 30 * mm, W, 30 * mm, stroke=0, fill=1)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 20)
    c.drawString(18 * mm, H - 15 * mm, "BLE - DirCon Bridge")
    c.setFont("Helvetica", 12)
    c.drawString(18 * mm, H - 23 * mm, "Device recovery guide")
    c.setFont("Helvetica", 9)
    c.drawRightString(W - 18 * mm, H - 23 * mm, "%s  |  USB recovery" % MF)
    c.setFillColor(NAVY)
    c.rect(0, 0, W, 11 * mm, stroke=0, fill=1)
    c.setFillColor(colors.white)
    c.setFont("Helvetica", 8.5)
    c.drawString(18 * mm, 4.2 * mm, "%s  |  USB recovery" % MF)
    c.drawRightString(W - 18 * mm, 4.2 * mm, "Page %d" % doc.page)
    c.restoreState()


doc = BaseDocTemplate(OUT, pagesize=A4, title="BLE - DirCon Bridge - Device recovery guide", author=MF)
doc.addPageTemplates([PageTemplate(id="m", onPage=decorate, frames=[
    Frame(18 * mm, 15 * mm, W - 36 * mm, H - 30 * mm - 15 * mm, leftPadding=0, rightPadding=0, topPadding=6, bottomPadding=0)])])

S = []
S.append(Paragraph("1. When to use this guide", h1))
S.append(P("Use it when the bridge no longer starts at all: no LED flash when power is connected, the status page never appears, or a firmware update left it dead. "
           "Try the simple things first: disconnect and reconnect the power; the factory reset with both buttons; the Wi-Fi setup with the Wi-Fi setup button (see the user manual). "
           "If none of these help, the bridge is recovered by writing a complete firmware image over the USB-C cable. The chip's built-in loader cannot be damaged by a faulty firmware, so this always works."))
S.append(Spacer(1, 4))
S.append(notebox("The recovery writes the whole firmware. <b>Option A</b> (full recovery) also erases the Wi-Fi network, the paired sensors and the settings; afterwards the bridge starts its Wi-Fi setup. "
                 "<b>Option B</b> keeps them, but does not help when a stored setting caused the problem."))

S.append(Paragraph("2. What you need, and where to get it", h1))
S.append(grid([
    [hdr("Item"), hdr("Where to get it")],
    [P("<b>Recovery file</b><br/>(one .bin file, a complete image)", cell), P("From %s, together with the bridge or on request. It is a <b>different file</b> than the one used for the update on the maintenance page. Do not rename the content; the name may vary." % MF, cell)],
    [P("<b>Chrome or Edge</b><br/>(method 1, recommended)", cell), P("Chrome: <font face='Courier'>https://www.google.com/chrome/</font>. Edge (included in Windows): <font face='Courier'>https://www.microsoft.com/edge</font>. The flashing page is Espressif's web flasher, <font face='Courier'>https://espressif.github.io/esptool-js/</font>.", cell)],
    [P("<b>USB-C cable</b>", cell), P("It must carry <b>data</b>, not only power. A cable that comes with a charger only may not work.", cell)],
    [P("<b>esptool</b><br/>(method 2 only; Espressif's official flash tool)", cell), P("Free, for Windows, macOS and Linux. Program and documentation: <font face='Courier'>https://github.com/espressif/esptool</font> (releases) and <font face='Courier'>https://docs.espressif.com/projects/esptool/</font>. Installed with Python (section 6) or as a ready-made program from the GitHub Releases page (Windows x86_64; macOS Intel and Apple silicon; Linux x86_64, armv7, aarch64).", cell)],
    [P("<b>Python 3.10 or newer</b><br/>(method 2 only, to install esptool with pip)", cell), P("Windows and macOS: <font face='Courier'>https://www.python.org/downloads/</font>. Linux: usually installed, otherwise from your package manager.", cell)],
    [P("<b>Access to the BOOT button</b><br/>(only if needed)", cell), P("Normally not needed: the bridge goes into download mode by itself (step 1). Only if that fails, you need the small button marked <b>B</b> (BOOT) on the XIAO ESP32S3 board inside the bridge. You may need to open the box or use the access hole, if the box has one. The button marked <b>R</b> is RESET.", cell)],
], [52 * mm, 122 * mm]))

S.append(Paragraph("3. Step 1: connect the bridge (first without the BOOT button)", h1))
S += steps([
    "Connect the bridge to the computer with the USB-C cable. <b>Do not press any button.</b>",
    "Carry on with method 1 (section 4) or method 2 (sections 6 to 8). In most cases the bridge goes into download mode by itself when the computer connects to it.",
    "Only if esptool reports <i>Failed to connect</i> or <i>Wrong boot mode</i> (or the browser cannot connect), or no serial port appears at all, put the bridge in download mode by hand (below) and run the command again.",
])
S.append(Paragraph("Putting the bridge in download mode by hand", h2))
S += steps([
    "Disconnect the USB-C cable from the bridge.",
    "Press and hold the <b>BOOT</b> button (B) on the XIAO board.",
    "While holding it, connect the USB-C cable to the computer. Then release the button.",
    "Alternative: with the cable connected, hold BOOT, press and release RESET (R) once, then release BOOT.",
])
S.append(P("The LEDs of the bridge stay off. Leave the cable connected until the flashing is finished.", sm))

S.append(CondPageBreak(60 * mm))
S.append(Paragraph("4. Method 1: web flasher (recommended, nothing to install)", h1))
S.append(P("The easiest way: it runs in the browser. You need <b>Google Chrome</b> or <b>Microsoft Edge</b> on Windows, macOS or Linux (Safari and Firefox cannot do this)."))
S.append(Spacer(1, 3))
S += steps([
    "Install Chrome if you do not have it: <font face='Courier'>https://www.google.com/chrome/</font> (Windows, macOS, Linux). Edge is included in Windows; other systems can get it from <font face='Courier'>https://www.microsoft.com/edge</font>.",
    "Connect the bridge as in step 1 (no button). Open <font face='Courier'>https://espressif.github.io/esptool-js/</font> in Chrome or Edge.",
    "Click <b>Connect</b>, choose the serial port of the bridge in the list and confirm. If the browser cannot connect, put the bridge in download mode by hand (step 1) and try again.",
    "Set the flash address to <b>0x0</b> and choose the recovery file. For option A first click the <b>Erase flash</b> button; for option B skip it. Click <b>Program</b> and wait until it is finished.",
    "Disconnect and reconnect the cable without holding BOOT. The four LEDs flash once. After option A the Wi-Fi LED blinks: set up the Wi-Fi network as described in the user manual.",
])
S.append(P("If the web flasher does not work on your computer, use method 2 below.", sm))

S.append(CondPageBreak(60 * mm))
S.append(Paragraph("5. Method 2: command line with esptool", h1))
S.append(P("For users who prefer the command line, or when the web flasher does not work. Sections 6 to 8 describe it for Windows, macOS and Linux."))

S.append(Paragraph("6. Method 2, step A: install esptool", h1))
S.append(KeepTogether([
    P("Windows", h2),
    *steps(["Install Python from python.org. In the installer, tick <i>Add python.exe to PATH</i>.",
            "Open PowerShell (Start menu, type PowerShell) and run:"]),
    C("py -m pip install esptool<br/>py -m esptool version"),
    P("Without Python: download the Windows .zip from the esptool GitHub Releases page, unzip it and run <font face='Courier'>esptool.exe</font> from that folder in PowerShell "
      "(use <font face='Courier'>.\\esptool.exe</font> in place of <font face='Courier'>py -m esptool</font> below). Antivirus software may warn about it.", sm)]))
S.append(KeepTogether([
    P("macOS", h2),
    P("Open Terminal (Applications, Utilities). Python 3 comes with the Xcode command line tools (macOS offers to install them) or from python.org. Then:"),
    C("python3 -m pip install --user esptool<br/>python3 -m esptool version"),
    P("Alternatives: with Homebrew, <font face='Courier'>brew install esptool</font>; or the ready-made macOS program from the GitHub Releases page (if macOS refuses to open it, right-click it and choose Open).", sm)]))
S.append(KeepTogether([
    P("Linux", h2),
    C("python3 -m pip install --user esptool<br/>python3 -m esptool version"),
    P("If pip answers <i>externally-managed-environment</i> (Debian, Ubuntu, Fedora and others), use <font face='Courier'>pipx install esptool</font> instead (install pipx with your package manager), "
      "or the ready-made Linux program from the GitHub Releases page. To open the serial port without sudo, add yourself to the serial group once, then log out and in again:", sm),
    C("sudo usermod -aG dialout $USER   # Arch and some others: uucp")]))

S.append(CondPageBreak(55 * mm))
S.append(Paragraph("7. Method 2, step B: find the serial port", h1))
S.append(P("With the bridge connected (in download mode by hand only if step 1 required it):"))
S.append(Spacer(1, 3))
S.append(grid([
    [hdr("System"), hdr("How to find the port"), hdr("Looks like")],
    [P("<b>Windows</b>", cell), P("Device Manager, section <i>Ports (COM &amp; LPT)</i>: an entry such as <i>USB Serial Device</i> or <i>USB JTAG/serial debug unit</i> appears when you connect the bridge.", cell), P("COM5", cell)],
    [P("<b>macOS</b>", cell), P("Terminal: <font face='Courier'>ls /dev/cu.usbmodem*</font>", cell), P("/dev/cu.usbmodem1101", cell)],
    [P("<b>Linux</b>", cell), P("Terminal: <font face='Courier'>ls /dev/ttyACM*</font>", cell), P("/dev/ttyACM0", cell)],
], [24 * mm, 100 * mm, 50 * mm]))
S.append(Spacer(1, 3))
S.append(P("If nothing appears, see the troubleshooting table. Windows 10 and 11 normally need no extra driver.", sm))

S.append(Paragraph("8. Method 2, step C: write the firmware", h1))
S.append(P("Open a terminal in the folder with the recovery file (or give the full path). Replace TOOL, PORT and FILE.bin as in the table:"))
S.append(Spacer(1, 3))
S.append(grid([
    [hdr("System"), hdr("TOOL"), hdr("PORT (example)")],
    [P("Windows", cell), P("<font face='Courier'>py -m esptool</font>", cell), P("COM5", cell)],
    [P("macOS", cell), P("<font face='Courier'>python3 -m esptool</font>", cell), P("/dev/cu.usbmodem1101", cell)],
    [P("Linux", cell), P("<font face='Courier'>python3 -m esptool</font>", cell), P("/dev/ttyACM0", cell)],
], [40 * mm, 70 * mm, 64 * mm]))
S.append(Paragraph("Option A: full recovery (erases the settings)", h2))
S.append(C("TOOL --chip esp32s3 --port PORT write-flash --erase-all 0x0 FILE.bin"))
S.append(Paragraph("Option B: keep Wi-Fi network, pairings and settings", h2))
S.append(C("TOOL --chip esp32s3 --port PORT write-flash 0x0 FILE.bin"))
S.append(P("Example (Windows, option A): <font face='Courier'>py -m esptool --chip esp32s3 --port COM5 write-flash --erase-all 0x0 DirCon_recovery.bin</font>. "
           "esptool connects, shows a progress percentage and ends with <i>Hash of data verified</i> and <i>Hard resetting via RTS pin</i>. "
           "If the pip script or the ready-made program is on your PATH, <font face='Courier'>esptool</font> alone works as TOOL. "
           "With an older esptool (version 4) the command is written <font face='Courier'>write_flash</font>.", sm))
S.append(Paragraph("Restart and check", h2))
S += steps([
    "Wait for the message <i>Hard resetting</i>, then disconnect and reconnect the USB-C cable without holding BOOT.",
    "The four LEDs flash once. After option A the Wi-Fi LED blinks: set up the Wi-Fi network as described in the user manual. After option B the bridge connects to the stored network.",
    "If the LEDs do not flash, repeat from step 1 (this time with the download mode by hand) and check the troubleshooting table.",
])

S.append(CondPageBreak(110 * mm))
S.append(Paragraph("9. Troubleshooting", h1))
S.append(grid([
    [hdr("What you see"), hdr("What to do")],
    [P("No serial port appears", cell), P("Use another USB-C cable (a <b>data</b> cable) and another USB port, without a hub. Try the download mode procedure by hand (step 1) and repeat it exactly; the board must be disconnected while you start holding BOOT.", cell)],
    [P("<i>Failed to connect</i> or <i>Wrong boot mode detected</i>", cell), P("The bridge is not in download mode. Put it in download mode by hand: disconnect, hold BOOT, connect, release, and run the command again at once. Check that PORT is the right port.", cell)],
    [P("<i>Permission denied</i> or could not open port (Linux)", cell), P("Add yourself to the serial group (section 6), log out and in; or run the command with sudo once. Close any serial monitor that uses the port.", cell)],
    [P("Port busy or access denied (Windows, macOS)", cell), P("Close programs that use the port (Arduino serial monitor, other terminals) and try again.", cell)],
    [P("The port disappears during the transfer", cell), P("The chip left download mode. Start again from step 1 (with BOOT held, if that was needed) and do not touch the cable; use a USB port directly on the computer.", cell)],
    [P("<i>command not found</i> / <i>No module named esptool</i>", cell), P("Use the <font face='Courier'>py -m esptool</font> or <font face='Courier'>python3 -m esptool</font> form, or check that Python and the install in section 6 completed.", cell)],
    [P("<i>Invalid choice: write_flash</i> or <i>write-flash</i>", cell), P("Different esptool version: version 5 uses <font face='Courier'>write-flash</font>, version 4 <font face='Courier'>write_flash</font>.", cell)],
    [P("Flashing succeeded but the LEDs stay off", cell), P("Wrong file (for example the update file instead of the recovery file) or a damaged download. Ask %s for the recovery file and repeat with option A." % MF, cell)],
], [58 * mm, 116 * mm]))
S.append(Spacer(1, 6))
S.append(P("Tool versions and links checked November 2026. Sources: Espressif esptool documentation (docs.espressif.com/projects/esptool) and the esptool GitHub repository; "
           "boot button procedure: Seeed Studio XIAO ESP32S3 documentation (wiki.seeedstudio.com).", small))
doc.build(S)
print("ok ->", OUT)
