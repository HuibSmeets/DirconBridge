# Shared styles, colours, table helpers and the two box drawings.
# Executed (exec) by make_manual2.py and make_recovery.py; it builds nothing by itself.
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table,
                                TableStyle, Image, KeepTogether, PageBreak)
from reportlab.graphics.shapes import Drawing, Rect, Circle, String

NAVY = colors.HexColor("#12355b")
GREY = colors.HexColor("#5b6572")
LIGHT = colors.HexColor("#e8edf3")
AMBER = colors.HexColor("#fff4d6")
AMBER_LINE = colors.HexColor("#e0a800")

OUT = "DirCon_Bridge_User_Manual.pdf"      # overwritten by the scripts that exec this file
VERSION = "2026.1.1"

body = ParagraphStyle("body", fontName="Helvetica", fontSize=9.6, leading=13, textColor=colors.HexColor("#1b1f24"))
small = ParagraphStyle("small", parent=body, fontSize=8.6, leading=11.4)
cell = ParagraphStyle("cell", parent=body, fontSize=8.8, leading=11.4)
cellb = ParagraphStyle("cellb", parent=cell, fontName="Helvetica-Bold")
h1 = ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=13, leading=16, textColor=NAVY, spaceBefore=9, spaceAfter=3, keepWithNext=1)
cap = ParagraphStyle("cap", parent=small, textColor=GREY, alignment=TA_CENTER)
step = ParagraphStyle("step", parent=body, leftIndent=16, firstLineIndent=-16, spaceAfter=2.5)
note = ParagraphStyle("note", parent=small)


def steps(items):
    return [Paragraph("<b>%d.</b>&nbsp;&nbsp;%s" % (i + 1, t), step) for i, t in enumerate(items)]


def notebox(text):
    t = Table([[Paragraph(text, note)]], colWidths=[174 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), AMBER),
        ("LINEBEFORE", (0, 0), (0, -1), 3, AMBER_LINE),
        ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return t


def grid(rows, widths, header=True):
    t = Table(rows, colWidths=widths, repeatRows=1 if header else 0)
    st = [("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#b8c0cc")),
          ("VALIGN", (0, 0), (-1, -1), "TOP"),
          ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
          ("TOPPADDING", (0, 0), (-1, -1), 2.8), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.8)]
    if header:
        st += [("BACKGROUND", (0, 0), (-1, 0), NAVY), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white)]
    t.setStyle(TableStyle(st))
    return t


def hdr(txt):
    return Paragraph("<font color='white'><b>%s</b></font>" % txt, cell)


# ---------------------------------------------------------------- box drawings (front and back)
def front_view():
    d = Drawing(250, 96)
    d.add(Rect(2, 14, 246, 62, rx=9, ry=9, fillColor=LIGHT, strokeColor=NAVY, strokeWidth=1.4))
    labels = ["Wi-Fi", "HR", "Cadence/Power", "DirCon"]
    for i, lab in enumerate(labels):
        cx = 40 + i * 57
        d.add(Circle(cx, 55, 7, fillColor=colors.white, strokeColor=NAVY, strokeWidth=1.2))
        d.add(String(cx, 28, lab, fontName="Helvetica", fontSize=7.6, textAnchor="middle", fillColor=NAVY))
    d.add(String(125, 2, "Front", fontName="Helvetica-Bold", fontSize=8.5, textAnchor="middle", fillColor=GREY))
    return d


def back_view():
    d = Drawing(250, 96)
    d.add(Rect(2, 14, 246, 62, rx=9, ry=9, fillColor=LIGHT, strokeColor=NAVY, strokeWidth=1.4))
    d.add(Rect(103, 50, 44, 13, rx=6.5, ry=6.5, fillColor=colors.HexColor("#3a4350"), strokeColor=NAVY))
    d.add(String(125, 38, "USB-C (power)", fontName="Helvetica", fontSize=7.6, textAnchor="middle", fillColor=NAVY))
    d.add(Circle(48, 56, 9, fillColor=colors.white, strokeColor=NAVY, strokeWidth=1.4))
    d.add(String(48, 34, "Pairing", fontName="Helvetica", fontSize=7.6, textAnchor="middle", fillColor=NAVY))
    d.add(Circle(202, 56, 9, fillColor=colors.white, strokeColor=NAVY, strokeWidth=1.4))
    d.add(String(202, 34, "Wi-Fi setup", fontName="Helvetica", fontSize=7.6, textAnchor="middle", fillColor=NAVY))
    d.add(String(125, 2, "Back (seen from behind)", fontName="Helvetica-Bold", fontSize=8.5, textAnchor="middle", fillColor=GREY))
    return d
